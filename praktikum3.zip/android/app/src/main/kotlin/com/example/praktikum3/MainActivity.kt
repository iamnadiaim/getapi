package com.example.praktikum3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
